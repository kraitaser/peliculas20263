import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}
class AppState extends StateLessWidget {
  const AppState({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers:[
        ChangeNotifierProvider(
          create: (_) => MovieProvider(),
        )
      ]
      child:MyApp(),
    )
  }
}class <MyApp({super.key})
const MyApp({super.key)};

@override
widget build(BuildContext context) {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Peliculas',
    initialRoute: 'home',
    routes: {
      'home': (_) => HomeScreen(),
      'details': (_) => DetailsScreen(),
    }
  )
)
