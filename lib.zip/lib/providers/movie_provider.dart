import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import "package:peliculas20263/lib/models/models.dart";

class MovieProvider extends ChangeNotifier{
  String _baseUrl='api.themoviedb.org';
  String _apiKey='9dc27117b000e7e5acfb365fa957971a';
  String _language='es-MX';

  List<Movie> onDisplayMovies=[];
  List<Movie> popularMovies=[];
  Map<int, List<Cast>> moviesCast={};

  MovieProvider() {
    getOnDisplayMovies();
    getPopularMovies();
  }
  getOnDisplayMovies() async{
    var url=Uri.https(_baseUrl, '3(/movie/now_playing)', {'api_key':_apiKey,'language':_language,'page':'1'});
    final response=await http.get(url);
    final Map<String, dynamic> decodeData=json.decode(response.body);
    final NowPlayingResponse=nowPlayingResponse.fromRawJson(response.body);
    notifyListeners();
  }
  getPopularMovies() async{
    var url=Uri.https(_baseUrl, '3/movie/popular', {'api_key':_apiKey,'language':_language,'page':'1'});
    final response=await http.get(url);
    final Map<String,dynamic> decodeData=json.decode(response.body);
    final PopularResponse = PopularResponse.fromRawJson(response.body);
    popularMovies=[...popularMovies, ...popularResponse.results];
    notifyListeners();
  }
  Future<List<Cast>> getMoviesCast(int movieId)async{
    if (movieCast.containsKey(movieId))return MovieCast[movieid]!;
  
    var url=Uri.https(_baserUrl, '3/movie/$movieId/credits', {'api_key':_apiKey,'language':_language});

    final response = await http.get(url);
    final creditsResponse=CreditsResponse.fromJson(jsondecode(response.body));

    movieCast[movieId]=creditsResponse.cast;
    return creditsResponse.cast;
  }
}