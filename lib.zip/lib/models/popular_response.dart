import 'dart:convert';

import 'movie.dart';

class PopularResponse{
  int page;
  List<Movie> results;
  int totalPages;
  int totalResults;

  PopularResponse({
    required this.page,
    required this.results,
    required this.totalPages,
    required this.totalResults
  });

  factory PopularResponse.fromRawJson(String str)=> PopularResponse.fromJson(json.decode(str));
  factory PopularResponse.fromJson(Map<String,dynamic> json)=>PopularResponse(
    page:json['page'],
    results:List<Movie>.from(json['results'].map((x)=>Movie.fromJson(x))),
    totalPages:json['totalPages'],
    totalResults:json['totalResults']
  );
}